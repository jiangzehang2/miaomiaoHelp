package com.example.miaomiaohelp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiaomiaoHelpApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiaomiaoHelpApplication.class, args);
    }

}
