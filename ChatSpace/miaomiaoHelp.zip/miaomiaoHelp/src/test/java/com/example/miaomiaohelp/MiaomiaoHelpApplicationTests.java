package com.example.miaomiaohelp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiaomiaoHelpApplicationTests {

    @Test
    void contextLoads() {
    }

}
