package com.example.demo128.domain;

import jakarta.persistence.Id;
import lombok.Data;

@Data
public class User {
    @Id
    private Integer user_id;
    private String phone_number;
    private String avatar_url;
    private String password;
    private   int  account ;
    private String username;
    public int getAccount(){return account;}

    public String getphoneNumber() {
        return phone_number;
    }



    public String getPassword() {
        return password;
    }
    public String getName(){return username;}

   public void setAvatar(String avatarAddress)
    {
        this.avatar_url=avatarAddress;
    }
    public void setphoneNumber(String phoneNumber) {
        this.phone_number = phoneNumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public void setAccount(String account) {
        this.account = Integer.parseInt(account);
    }
   public void setAccount(int account){this.account= account;}
   public void setName(String name) { this.username=name;}
}

