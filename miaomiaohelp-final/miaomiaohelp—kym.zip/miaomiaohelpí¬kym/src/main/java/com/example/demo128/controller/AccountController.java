package com.example.demo128.controller;

import com.example.demo128.Response.AccountResponse;
import com.example.demo128.domain.User;
import com.example.demo128.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class AccountController {
    @Autowired
    private UserMapper userMapper;

    User user=new User();
    private int balance;
    @GetMapping("/api/account")
    public AccountResponse balance(String phoneNumber,int add)
    {
        userMapper.selectuser(phoneNumber);
        System.out.println(user.getAccount()+"aaaaaa");
        balance = user.getAccount();

        if(add==1)
        {
            balance=user.getAccount()+10;
        }
        if(add==2)
        {
            balance=user.getAccount()+20;
        }
        if(add==3)
        {
            balance=user.getAccount()+50;
        }
       if(add==4)
       {
           balance=user.getAccount()+100;
       }

        userMapper.account(phoneNumber,balance);
        AccountResponse response=new AccountResponse(balance);

     return response;
    }


}
