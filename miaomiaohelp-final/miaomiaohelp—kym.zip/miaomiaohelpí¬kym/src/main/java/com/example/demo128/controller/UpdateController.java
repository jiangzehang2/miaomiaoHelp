package com.example.demo128.controller;

import com.example.demo128.Response.ChangePasswordResponse;
import com.example.demo128.Response.getUserDetailsResponse;
import com.example.demo128.domain.User;
import com.example.demo128.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("api")
@CrossOrigin(origins="*")

public class UpdateController {
           @Autowired
         private UserMapper userMapper;
           @GetMapping("/update")
    public ChangePasswordResponse update(String name,String phoneNumber,String password)
           {
               //创建响应对象
               ChangePasswordResponse response=new ChangePasswordResponse();

               User user=new User();
               user.setPassword(password);
               user.setphoneNumber(phoneNumber);
               user.setName(name);
               userMapper.updateUser(phoneNumber,password,name);
               return response;
           }

          @GetMapping("/getUserDetails")
    public getUserDetailsResponse details(String phoneNumber)
           {
          System.out.println(phoneNumber+"#");
           User user=new User();
                   user=userMapper.selectuser(phoneNumber);
            System.out.println(user);
               //创建响应对象  user.getAccount()
               String name= user.getName();
               String password=user.getPassword();
               int account=user.getAccount();
           getUserDetailsResponse response=new getUserDetailsResponse(name,password,account);

               return response;

           }


}

