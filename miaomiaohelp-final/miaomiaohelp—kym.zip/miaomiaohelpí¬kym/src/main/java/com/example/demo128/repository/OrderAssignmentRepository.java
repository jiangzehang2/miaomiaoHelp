package com.example.demo128.repository;


import com.example.demo128.Entity.OrderAssignment;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderAssignmentRepository extends CrudRepository<OrderAssignment,Integer>{

}
