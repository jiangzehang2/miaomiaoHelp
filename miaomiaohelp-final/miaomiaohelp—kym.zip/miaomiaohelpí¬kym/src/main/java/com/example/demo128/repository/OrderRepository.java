package com.example.demo128.repository;


import com.example.demo128.Entity.Order;
import org.apache.catalina.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends CrudRepository<Order, Integer> {

    List<Order> findByUser(User user);


    List<Order> findByStatus(String status);
}
