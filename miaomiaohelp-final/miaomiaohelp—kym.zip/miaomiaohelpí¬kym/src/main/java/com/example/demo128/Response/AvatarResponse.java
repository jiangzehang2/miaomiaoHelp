package com.example.demo128.Response;

public class AvatarResponse {
    private boolean success;
    private String message;

    // Getter and Setter methods

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
