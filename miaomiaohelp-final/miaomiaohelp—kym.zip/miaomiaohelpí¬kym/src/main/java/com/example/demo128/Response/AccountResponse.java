package com.example.demo128.Response;

public class AccountResponse {

        private boolean success; // 登录是否成功

       private int account;
    public AccountResponse (int account)
    {
        this.account=account;
    }

    public void setAccount(int account){this.account=account;}

    public int getAccount(){return account;}





        // Getter 和 Setter
        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }





}


