package com.example.demo128.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users") // 映射到数据库中的表
public class User {

    @Id
    private Integer id;

    private String name;

    // getter 和 setter 方法
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAccount(String number) {
    }

    public void setPassword(String number) {
    }

    public void setUsername(String number) {
    }
}
