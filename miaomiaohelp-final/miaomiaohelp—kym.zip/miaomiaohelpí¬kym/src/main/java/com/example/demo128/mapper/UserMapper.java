package com.example.demo128.mapper;

import com.example.demo128.domain.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

@Repository
public interface UserMapper extends CrudRepository<User, Integer> {

    @Insert("INSERT into users(phone_number, password, account) values (#{phone_number}, #{password}, #{account})")
    int saveUser(@Param("phone_number") String phone_number,
                 @Param("password") String password,
                 @Param("account") String account);

    @Select("select user_id, phone_number, password, username, account from users where phone_number=#{phone_number}")
    User selectuser(@Param("phone_number") String phone_number);

    // 更新用户密码（明文）
    @Update("UPDATE users SET phone_number=#{phone_number}, password=#{password}, username=#{username} where phone_number=#{phone_number}")
    int updateUser(@Param("phone_number") String phone_number,
                   @Param("password") String password,
                   @Param("username") String username);

    @Update("UPDATE users SET account=#{account} where phone_number=#{phone_number}")
    int account(@Param("phone_number") String phone_number,
                @Param("account") int account);
}
