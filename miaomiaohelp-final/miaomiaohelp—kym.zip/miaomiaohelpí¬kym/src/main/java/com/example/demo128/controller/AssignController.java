package com.example.demo128.controller;


import com.example.demo128.Entity.Order;
import com.example.demo128.Entity.OrderAssignment;
import com.example.demo128.Entity.User;
import com.example.demo128.repository.OrderAssignmentRepository;
import com.example.demo128.repository.OrderRepository;
import com.example.demo128.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path="/Assign")
public class AssignController {
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    OrderAssignmentRepository orderAssignmentRepository;

    @Operation(description = "接取订单接口")
    @PostMapping(path="/accept")
    public @ResponseBody String accept(@RequestParam(value = "OrderId") int orderid,
                                       @RequestParam(value = "RunnerId") int runnerid
                                                                )
    {
       Order order=orderRepository.findById(orderid).get();
       order.setStatus("pending");
        orderRepository.save(order);

        User user= (User) userRepository.findById(runnerid).get();

        OrderAssignment orderAssignment=new OrderAssignment();
        orderAssignment.setOrder(order);

        orderAssignment.setRunner(user);
        orderAssignmentRepository.save(orderAssignment);

        return "success";
    }




    @Operation(description = "完成订单")
    @PostMapping(path="/complete")
    public @ResponseBody String cpmplete(@RequestParam(value = "订单id" ) int orderassignid){
        OrderAssignment orderAssignment=orderAssignmentRepository.findById(orderassignid).get();
        orderAssignment.setStatus("completed");
        orderAssignmentRepository.save(orderAssignment);

        Order order=orderAssignment.getOrder();
        order.setStatus("completed");
        orderRepository.save(order);
        return "success";

    }
}
