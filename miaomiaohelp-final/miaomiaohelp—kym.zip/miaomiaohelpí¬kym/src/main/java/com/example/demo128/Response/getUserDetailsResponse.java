package com.example.demo128.Response;


public class getUserDetailsResponse {
    private boolean success; // 登录是否成功


    private  String name;
    private String password;

    private int account;



  public getUserDetailsResponse(String name,String password,int account)
  {
      this.name=name;
      this.password=password;
      this.account=account;
  }
    public String getName() {
        return name;
    }

    public void setAccount(int account){ this.account=account;}

    public int  getAccount(){return account;}

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Getter 和 Setter
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }


}