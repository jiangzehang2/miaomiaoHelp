INSERT INTO `tab`(`id`, `name`, `phoneNumber`, `password`) VALUES (1, 'kym', '18164917544', 'kym1122');
INSERT INTO `tab`(`id`, `name`, `phoneNumber`, `password`) VALUES (2, NULL, '12345678', '123456');
