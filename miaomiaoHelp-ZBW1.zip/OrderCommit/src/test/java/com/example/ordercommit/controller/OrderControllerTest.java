package com.example.ordercommit.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderControllerTest {

    @Test
    void addOrder() {

    }

    @Test
    void getAllOrders() {
    }

    @Test
    void getMyOrders() {
    }

    @Test
    void download() {
    }
}