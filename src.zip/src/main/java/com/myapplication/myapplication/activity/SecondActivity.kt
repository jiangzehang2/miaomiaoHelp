package com.myapplication.myapplication.com.myapplication.myapplication.activity

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.myapplication.myapplication.MainActivity
import com.myapplication.myapplication.R
import com.myapplication.myapplication.ui.theme.MyApplicationTheme

class SecondActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RegisterScreen()
            }
        }
    }
}
@Composable
fun  RegisterScreen() {
    // 获取 Context
    val context = LocalContext.current

    // 嵌入 XML 布局到 Compose 中
    AndroidView(
        factory = { ctx ->
            // 加载 register.xml 布局
            android.view.LayoutInflater.from(ctx).inflate(R.layout.register, null).apply {
                // 获取登录界面注册按钮的 ID 并设置点击事件
                findViewById<ImageButton>(R.id.btnSubmit).setOnClickListener {
                    // 跳转到 SecondActivity
                    context.startActivity(Intent(context, MainActivity::class.java))
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
