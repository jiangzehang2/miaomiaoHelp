package com.myapplication.myapplication.network;

public class RegisterRequest {
}
