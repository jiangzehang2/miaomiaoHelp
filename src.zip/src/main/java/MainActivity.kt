package com.myapplication.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import com.myapplication.myapplication.com.myapplication.myapplication.activity.MenuActivity
import com.myapplication.myapplication.com.myapplication.myapplication.activity.SecondActivity
import com.myapplication.myapplication.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LoginScreen()
            }
        }
    }
}

@Composable
fun LoginScreen() {
    // 获取 Context
    val context = LocalContext.current

    // 嵌入 XML 布局到 Compose 中
    AndroidView(
        factory = { ctx ->
            // 加载 login.xml 布局
            android.view.LayoutInflater.from(ctx).inflate(R.layout.login, null).apply {
                // 获取登录界面注册按钮的 ID 并设置点击事件
                findViewById<ImageButton>(R.id.btnGoToRegister).setOnClickListener {
                    // 跳转到 SecondActivity
                    context.startActivity(Intent(context, SecondActivity::class.java))
                }
                // 获取登录界面登录按钮的 ID 并设置点击事件
                findViewById<ImageButton>(R.id.loimg).setOnClickListener {
                    // 跳转到 MenuActivity
                    context.startActivity(Intent(context, MenuActivity::class.java))
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}