package com.example.bookmanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmanageApplicationTests {

    @Test
    void contextLoads() {
    }

}
